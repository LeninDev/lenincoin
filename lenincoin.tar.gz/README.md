# lenincoin 
Website project https://lenincoin.com
is an experimental digital currency that enables instant payments to anyone,
anywhere in the world.
Use of peer-to-peer technology to operate with no central authority:
managing transactions and issuing money are carried out collectively by the network.
Open source software which enables the use of this currency.
Lenin units are VIL in which you can send and recieve, exchange and store as value over the p2p network provided.
sha256 
100 VIL per block

RPC port: 10156

P2P PORT: 10157
